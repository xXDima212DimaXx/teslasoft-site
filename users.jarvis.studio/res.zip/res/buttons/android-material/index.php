<?php
$value=$_GET['value'];
$background=$_GET['background'];
$background_highlight=$_GET['background-highlight'];
$text_color_highlight=$_GET['text-color-highlight'];
$ripple=$_GET['ripple'];
$text_color=$_GET['text-color'];
$width=$_GET['width'];
$height=$_GET['height'];
$command=$_GET['command'];
$border_radius=$_GET['border-radius'];
$font_size=$_GET['font-size'];
$margin=$_GET['margin'];
if($value==''){$value="Button";}
if($background==''){$background="323232";}
if($background_highlight==''){$background_highlight="424242";}
if($text_color_highlight==''){$text_color_highlight="ffffff";}
if($ripple==''){$ripple="rgba(255,255,255,0.3)";}
if($text_color==''){$text_color="cecece";}
if($width==''){$width="auto";}
if($height==''){$height="auto";}
if($command==''){$command="";}
if($border_radius==''){$border_radius="3px";}
if($font_size==''){$font_size="16px";}
if($margin==''){$margin="0px";}
echo <<<EOL
<!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title>jarvis-res-web-btn-mtrl</title><meta name="viewport" content="width=device-width, user-scalable=no"><link rel="icon" type="image/png" href="/home/images/jarvis.png"><link rel="stylesheet" href="/res/buttons/android-material/css/materialize.css"><link rel="stylesheet" href="/res/buttons/android-material/css/gui.css">
<style>.middle{width:100vw;text-align:center}.btn-large{border:none;margin: $margin;border-radius:$border_radius;font-size:$font_size;display:inline-block;height:36px;line-height:36px;padding:016px;text-transform:none;vertical-align:middle;background-color:#$background;color:#$text_color;width:$width;height:$height;text-align:center;-webkit-tap-highlight-color:transparent}.waves-effect.waves-def .waves-ripple{background-color:$ripple}.btn-large:hover{background-color:#$background_highlight;color:#$text_color_highlight}.btn-large:focus{background-color:#$background_highlight;color:#$text_color_highlight}</style>
</head><body><div class = "middle"><button class="waves-effect waves-def btn-large" href="#" onclick="javascript:runCommand()">$value</button></div><script src="/res/buttons/android-material/js/materialize.js"></script><script>function runCommand(){window.location.assign("$command");}</script></body></html>
EOL;
?>